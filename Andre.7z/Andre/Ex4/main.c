#include <stdio.h>

int main() {
    int vet[20];
    float media;
    int sum = 0;

    for (int i = 0; i < 20; ++i) {
        scanf("%d", &vet[i]);

        if(vet[i] % 2 == 0){
            sum += vet[i];

            media = sum / 20;
        }

    }

    printf("%.02f", media);

    return 0;
}
