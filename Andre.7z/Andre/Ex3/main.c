#include <stdio.h>

int main() {
    int vet[5] = {1,2,3,4,5};

    for (int i = 0; i < 5; ++i) {
        printf("%d", vet[i]);
    }

    printf("\n");

    int inicio = 0;

    int fim = 5 - 1;

    int temp;

    while( inicio < fim){
        temp = vet[inicio];
        vet[inicio] = vet[fim];
        vet[fim] = temp;

        inicio++;
        fim--;

    }
    printf("vetor invertido: ");
    for (int i = 0; i < 5; ++i) {
        printf("%d", vet[i]);
    }


    return 0;
}
