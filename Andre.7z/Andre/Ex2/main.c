#include <stdio.h>

int main() {
    int vet[10] = {3,1,9,3,4, 8, 19, 2, 4, 9};
    int maior = 0;

    for (int i = 0; i <= 10; ++i) {
        if (maior < vet[i]){
            maior = vet[i];
        }
    }

    printf("O maior valor do vetor eh: %d", maior);

    return 0;
}
