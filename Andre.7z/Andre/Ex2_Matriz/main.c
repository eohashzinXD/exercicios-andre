#include <stdio.h>

#define COLS 3
#define ROWS 3

int ehPrimo(int num){
    if(num <= 1){
        return 0;//numeros menores ou igual a 1 nao sao primos
    }
    for (int i = 2; i * i <= num ; ++i) {
        if(num % i == 0){
            return 0;// Se o número é divisível por algum número além de 1 e ele mesmo, não é primo
        }
    }
    return 1;// Se nenhum divisor foi encontrado, o número é primo
}

int contarPrimosNaMatriz(int matriz[ROWS][COLS]){
    int count = 0;
    for (int i = 0; i < ROWS; ++i) {
        for (int j = 0; j < COLS; ++j) {
            if(ehPrimo(matriz[i][j])){
                count++;
            }
        }
    }
    return count;
}

int main() {
    int matriz[ROWS][COLS] = {
            {2, 3, 4},
            {5, 6, 7},
            {8, 9, 10}
    };

    int numerosPrimos = contarPrimosNaMatriz(matriz);

    printf("O numero de numeros primos na matriz eh: %d\n", numerosPrimos);

    return 0;
}
