#include <stdio.h>

int main() {
    int vet[100]; // Tamanho máximo do vetor (altere conforme necessário)
    int tam, val, count = 0;

    printf("Digite o tamanho do vetor: ");
    scanf("%d", &tam);

    printf("Digite os elementos do vetor:\n");
    for (int i = 0; i < tam; i++) {
        scanf("%d", &vet[i]);
    }

    printf("Digite o valor a ser contado: ");
    scanf("%d", &val);

    for (int i = 0; i < tam; i++) {
        if (vet[i] == val) {
            count++;
        }
    }

    printf("O valor %d aparece %d vezes no vetor.\n", val, count);

    return 0;
}
