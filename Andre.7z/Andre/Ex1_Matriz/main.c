#include <stdio.h>

#define COLS 3
#define ROWS 3

int main() {
    double media[2] = {0};

    int matriz[ROWS][COLS] = {
        {1, 2, 3},
        {4, 5, 6},
        {7, 8, 9}
    };

    for (int cols = 0; cols < COLS; ++cols) {
        double soma = 0;
        for (int row = 0; row < ROWS; ++row) {
            soma += matriz[row][cols];
        }
        media[cols] = soma / ROWS;
    }

    for (int col = 0; col < COLS; ++col) {
        printf("%.2f\n",media[col] );
    }



    return 0;
}
