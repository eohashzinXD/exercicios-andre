#include <stdio.h>
#include <stdlib.h>


double fat(int numero){
	double fatorial = 1.0;
	 
	int i;
	
	for(i = 1; i <= numero; i++){
		fatorial = fatorial * i;
	}
	return fatorial;
}



int main(int argc, char *argv[]) {
	int numero = 4;
	
	double fatorial;
	
	fatorial = fat(numero);
	
	printf("%lf", fatorial);
	
	return 0;
}
