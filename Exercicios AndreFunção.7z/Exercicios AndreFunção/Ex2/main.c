#include <stdio.h>
#include <stdlib.h>


int validarTriangulo(int lado1, int lado2, int lado3){
	printf("Digite os tres lados do triangulo:\n");
    printf("Lado 1: ");
    scanf("%i", &lado1);
    printf("Lado 2: ");
    scanf("%i", &lado2);
    printf("Lado 3: ");
    scanf("%i", &lado3);
    
    if(lado1 + lado2 > lado3 && lado1 + lado3 > lado2 && lado2 + lado3 > lado1){
    	if (lado1 == lado2 && lado2 == lado3) {
            printf("Verdadeiro.\n");
        }
	}else{
		printf("Falso \n");
	}
}

int main(int argc, char *argv[]) {
	
	int lado1, lado2, lado3;
	
	int triangulo = validarTriangulo(lado1 ,lado2, lado3);
	
	return 0;
}
